# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM ecommerce.mental_health.bronze_social_media_raw;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC What I Achieved:
# MAGIC
# MAGIC - Used Unity Catalog Volume for governed storage.
# MAGIC - Ingested raw data into Bronze Delta table.
# MAGIC - Followed Medallion Architecture principles.
# MAGIC - Ensured reproducibility and auditability.
# MAGIC
# MAGIC The dataset social_media_mental_health.csv was uploaded to a Unity Catalog Volume and ingested into a Bronze Delta table without transformation to preserve raw data integrity.

# COMMAND ----------

# DBTITLE 1,Validate
spark.table("ecommerce.mental_health.bronze_social_media_raw").printSchema()
spark.table("ecommerce.mental_health.bronze_social_media_raw").count()


# COMMAND ----------

# DBTITLE 1,Write Bronze Delta Table (Raw Layer)
# Read CSV from Unity Catalog Volume
df_raw = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("/Volumes/ecommerce/bronze/raw_files/social_media_mental_health.csv")

# Write to Bronze Delta table
df_raw.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("ecommerce.mental_health.bronze_social_media_raw")



# COMMAND ----------

# DBTITLE 1,Create a Separate Schema for Social media Mental Health Project
# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS ecommerce.mental_health;
# MAGIC

# COMMAND ----------

# DBTITLE 1,read raw csv from volume
file_path = "/Volumes/ecommerce/bronze/raw_files/social_media_mental_health.csv"

df_raw = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load(file_path)

display(df_raw)
